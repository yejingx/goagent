#!/usr/bin/env python
# coding:utf-8

import sys
import os
import re
try:
    import argparse
except:
    argparse = None

try:
    import configparser
except ImportError:
    import ConfigParser as configparser


BANNER = '''\
===============================================================
 GoAgent服务端部署程序, 开始上传 python 应用文件夹
 Linux/Mac 用户, 请使用 python uploader.zip 来上传应用
 Windows 用户, uploader.exe 的审查方法请见 github.com/goagent/pybuild
===============================================================

请输入您的appid, 多个appid请用|号隔开
注意：appid 请勿包含 android/ios 字样，否则可能被某些网站识别成移动设备。
'''

FOOTER = '''\
上传成功，请检查proxy.ini是否更新成功，谢谢。按回车键退出程序。
'''

FOOTER_REMINDER='''\
上传成功，请不要忘记编辑proxy.ini把你的appid填进去，谢谢。按回车键退出程序。
'''

CONFIG_FILENAME='proxy.ini'

def main():
    print BANNER.decode('utf-8').encode(sys.getfilesystemencoding(), 'replace')
    
    import mimetypes
    mimetypes._winreg = None
    import appcfg
    dirname = os.path.dirname(os.path.abspath(__file__))
    CONFIG_PATH = None
    if dirname.endswith('.zip'):
    	dirname = os.path.dirname(dirname)
        CONFIG_PATH = dirname + '/../local/' + CONFIG_FILENAME
    else:
        CONFIG_PATH = dirname + '/../../local/' + CONFIG_FILENAME
    os.chdir(dirname)
    appids = appcfg.main()
    if argparse:
        cmd_parser = argparse.ArgumentParser(description="uploader -- GoAgent GAE deploy utility")
        cmd_parser.add_argument('-e', '--update-ini', action='store_true', help="Update appid in proxy.ini if upload successfully")
        cmd_args = cmd_parser.parse_args()
        if cmd_args.update_ini:
            configparser.RawConfigParser.OPTCRE = re.compile(r'(?P<option>[^=\s][^=]*)\s*(?P<vi>[=])\s*(?P<value>.*)$')
            ini_parser = configparser.ConfigParser()
            ini_parser.read(CONFIG_PATH)
            ini_parser.set('gae', 'appid', appids)
            with open(CONFIG_PATH, 'wb') as fp:
                ini_parser.write(fp)

        print
        print FOOTER.decode('utf-8').encode(sys.getfilesystemencoding(), 'replace')
    else:
        print
        print FOOTER_REMINDER.decode('utf-8').encode(sys.getfilesystemencoding(), 'replace')

if __name__ == '__main__':
   try:
        main()
        raw_input()
   except KeyboardInterrupt:
        pass